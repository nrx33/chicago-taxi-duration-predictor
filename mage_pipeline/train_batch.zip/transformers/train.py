import mlflow
import time
import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import os
import boto3
from xgboost import XGBRegressor

# Set environment variables for MLflow to use LocalStack S3
os.environ['MLFLOW_S3_ENDPOINT_URL'] = 'http://localstack:4566'
os.environ['AWS_ACCESS_KEY_ID'] = 'test'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'test'
os.environ['MLFLOW_TRACKING_URI'] = 'http://mlflow:5000'

mlflow.set_tracking_uri('http://mlflow:5000')

# Configure the S3 client to use LocalStack
s3 = boto3.client('s3', endpoint_url='http://localstack:4566')
bucket_name = 'mlflow-bucket'

def configure_mlflow_for_localstack():
    # Check if the bucket exists and is accessible
    try:
        s3.head_bucket(Bucket=bucket_name)
        print(f"S3 bucket exists and is accessible: {bucket_name}")
    except Exception as e:
        print(f"Error accessing S3 bucket: {str(e)}")
        return False

    mlflow.set_experiment("Taxi Trip Duration Prediction")
    return True

def extract_duration(y):
    if isinstance(y, (list, np.ndarray)):
        return np.array([item['Duration'] for item in y])
    elif isinstance(y, pd.Series):
        return y.apply(lambda x: x['Duration']).values
    else:
        raise ValueError(f"Unsupported type for target variable: {type(y)}")

@transformer
def transform(data, *args, **kwargs):
    if not configure_mlflow_for_localstack():
        raise RuntimeError("Failed to configure MLflow with LocalStack")
    
    # Validate input data
    if not isinstance(data, dict):
        raise ValueError(f"Expected input data to be a dictionary, but got {type(data)}")
    
    required_keys = ['X_train', 'X_test', 'y_train', 'y_test']
    for key in required_keys:
        if key not in data:
            raise KeyError(f"Missing required key '{key}' in input data")

    # Unpack the input data
    X_train, X_test, y_train, y_test = data['X_train'], data['X_test'], data['y_train'], data['y_test']

    # Convert to numpy arrays if they're pandas DataFrames
    if isinstance(X_train, pd.DataFrame):
        X_train = X_train.values
    if isinstance(X_test, pd.DataFrame):
        X_test = X_test.values

    # Extract 'Duration' values from the target variables
    y_train = extract_duration(y_train)
    y_test = extract_duration(y_test)

    # Initialize models
    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=100, random_state=42),
        "XGBoost": XGBRegressor(n_estimators=100, random_state=42)
    }

    # Initialize best model tracking variables
    best_model_name = None
    best_mae = float("inf")
    best_r2 = float("-inf")
    best_rmse = float("inf")
    best_model = None

    # Wrap the loop with tqdm for progress bar
    pbar = tqdm(models.items(), desc="Training models")
    for name, model in pbar:
        start_time = time.time()
        
        try:
            with mlflow.start_run(run_name=name):
                # Train the model
                model.fit(X_train, y_train)
                
                # Predict and evaluate
                y_pred = model.predict(X_test)
                mae = mean_absolute_error(y_test, y_pred)
                rmse = mean_squared_error(y_test, y_pred, squared=False)
                r2 = r2_score(y_test, y_pred)
                
                # Log model and metrics
                mlflow.log_param("model", name)
                mlflow.log_metric("mae", mae)
                mlflow.log_metric("RMSE", rmse)
                mlflow.log_metric("R2", r2)
                mlflow.sklearn.log_model(model, "model")
                
                end_time = time.time()
                elapsed_time = end_time - start_time
                
                # Update progress bar description
                pbar.set_postfix({
                    'model': name, 
                    'time': f'{elapsed_time:.2f}s',
                    'MAE': f'{mae:.4f}', 
                    'RMSE': f'{rmse:.4f}', 
                    'R²': f'{r2:.4f}'
                })
                
                # Check if this model is the best based on the metrics
                if mae < best_mae and rmse < best_rmse and r2 > best_r2:
                    best_mae = mae
                    best_rmse = rmse
                    best_r2 = r2
                    best_model_name = name
                    best_model = model
        
        except Exception as e:
            print(f"Error occurred while training {name}: {str(e)}")

    if best_model is None:
        raise ValueError("No models were successfully trained.")

    print(f'Best model: {best_model_name} with MAE: {best_mae}, RMSE: {best_rmse}, R²: {best_r2}')

    # Return the best model and its metrics
    return {
        'best_model_name': best_model_name,
        'best_model': best_model,
        'best_mae': best_mae,
        'best_rmse': best_rmse,
        'best_r2': best_r2
    }