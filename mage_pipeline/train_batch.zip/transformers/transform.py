if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

@transformer
def transform(data, *args, **kwargs):
    """
    Transformer block for processing trip data.
    
    Args:
        data: The output from the upstream parent block (ingest block)
        args: The output from any additional upstream blocks (if applicable)
    
    Returns:
        dict: A dictionary containing the processed features and target variable
    """
    df = data[0] 

    # Fill or drop missing values
    df = df.dropna(subset=['Trip Miles', 'Trip Start Timestamp', 'Trip End Timestamp', 'Payment Type', 'Company', 'Duration'])

    # Convert Trip Start Timestamp and Trip End Timestamp to datetime
    df['Trip Start Timestamp'] = pd.to_datetime(df['Trip Start Timestamp'])
    df['Trip End Timestamp'] = pd.to_datetime(df['Trip End Timestamp'])

    # Extract useful time-based features
    df['Trip Start Hour'] = df['Trip Start Timestamp'].dt.hour
    df['Trip Start DayOfWeek'] = df['Trip Start Timestamp'].dt.dayofweek
    df['Trip End Hour'] = df['Trip End Timestamp'].dt.hour
    df['Trip End DayOfWeek'] = df['Trip End Timestamp'].dt.dayofweek

    # Select features
    features = df[['Trip Miles', 'Trip Start Hour', 'Trip Start DayOfWeek', 'Trip End Hour', 'Trip End DayOfWeek', 'Payment Type', 'Company']]
    target = df['Duration']

    # One-hot encode categorical features
    categorical_features = ['Payment Type', 'Company']
    encoder = OneHotEncoder(drop='first', sparse_output=False)
    encoded_features = pd.DataFrame(encoder.fit_transform(features[categorical_features]), columns=encoder.get_feature_names_out())

    # Combine encoded features with numerical features
    numerical_features = features.drop(columns=categorical_features)
    features_encoded = pd.concat([numerical_features.reset_index(drop=True), encoded_features.reset_index(drop=True)], axis=1)

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features_encoded, target, test_size=0.2, random_state=42)

    # Return the processed data as a dictionary
    return {
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test
    }