import os
import boto3
import mlflow
import numpy as np
import pandas as pd
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

def configure_mlflow_for_localstack():
    os.environ['MLFLOW_S3_ENDPOINT_URL'] = 'http://localstack:4566'
    os.environ['AWS_ACCESS_KEY_ID'] = 'test'
    os.environ['AWS_SECRET_ACCESS_KEY'] = 'test'
    os.environ['MLFLOW_TRACKING_URI'] = 'http://mlflow:5000'

    mlflow.set_tracking_uri('http://mlflow:5000')
    
    # Configure the S3 client to use LocalStack
    s3 = boto3.client('s3', endpoint_url='http://localstack:4566')
    bucket_name = 'mlflow-bucket'

    # Check if the bucket exists and is accessible
    try:
        s3.head_bucket(Bucket=bucket_name)
        print(f"S3 bucket exists and is accessible: {bucket_name}")
    except Exception as e:
        print(f"Error accessing S3 bucket: {str(e)}")
        return False

    mlflow.set_experiment("Taxi Trip Duration Prediction")
    return True

def extract_duration(y):
    if isinstance(y, (list, np.ndarray)):
        return np.array([item['Duration'] for item in y])
    elif isinstance(y, pd.Series):
        return y.apply(lambda x: x['Duration']).values
    else:
        raise ValueError(f"Unsupported type for target variable: {type(y)}")

@transformer
def transform(data, data_2, *args, **kwargs):
    if not configure_mlflow_for_localstack():
        raise RuntimeError("Failed to configure MLflow with LocalStack")

    required_keys_data = ['best_model_name', 'best_model']
    required_keys_data_2 = ['X_train', 'y_train', 'X_test', 'y_test']
    
    for key in required_keys_data:
        if key not in data:
            raise KeyError(f"Missing required key '{key}' in data")

    for key in required_keys_data_2:
        if key not in data_2:
            raise KeyError(f"Missing required key '{key}' in data_2")

    best_model_name = data['best_model_name']
    best_model = data['best_model']
    X_train = data_2['X_train']
    y_train = extract_duration(data_2['y_train'])
    X_test = data_2['X_test']
    y_test = extract_duration(data_2['y_test'])

    # Define hyperparameter grid based on the best model
    if best_model_name == "Random Forest":
        param_dist = {
            'n_estimators': [50, 100, 200],
            'max_depth': [None, 10, 20],
            'min_samples_split': [2, 5, 10]
        }
    elif best_model_name == "Gradient Boosting":
        param_dist = {
            'n_estimators': [50, 100, 200],
            'learning_rate': [0.01, 0.1, 0.2],
            'max_depth': [3, 5, 7]
        }
    elif best_model_name == "XGBoost":
        param_dist = {
            'n_estimators': [50, 100, 200],
            'learning_rate': [0.01, 0.1, 0.2],
            'max_depth': [3, 5, 7]
        }
    else:  # Linear Regression
        param_dist = {
            'fit_intercept': [True, False],
            'normalize': [True, False]
        }

    # Perform RandomizedSearchCV with parallel processing
    rand_search = RandomizedSearchCV(estimator=best_model, param_distributions=param_dist, cv=3, scoring='neg_mean_absolute_error', n_jobs=2, n_iter=10, random_state=42)
    rand_search.fit(X_train, y_train)

    best_model = rand_search.best_estimator_
    best_params = rand_search.best_params_
    print(f'Best parameters: {best_params}')

    # Register the best-tuned model on MLflow
    with mlflow.start_run(run_name=f'Tuned {best_model_name}'):
        y_pred = best_model.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = mean_squared_error(y_test, y_pred, squared=False)
        r2 = r2_score(y_test, y_pred)
        
        mlflow.log_param("model", best_model_name)
        mlflow.log_params(best_params)
        mlflow.log_metric("mae", mae)
        mlflow.log_metric("RMSE", rmse)
        mlflow.log_metric("R2", r2)
        mlflow.sklearn.log_model(best_model, "model")
        
        # Register the model in the Model Registry
        run_id = mlflow.active_run().info.run_id
        model_uri = f"runs:/{run_id}/model"
        mlflow.register_model(model_uri, best_model_name)
        
        print(f'Tuned {best_model_name} MAE: {mae}, RMSE: {rmse}, R²: {r2}')
        print(f'Run ID of the best-tuned model: {run_id}')

    return {
        'best_model_name': best_model_name,
        'best_model': best_model,
        'best_params': best_params,
        'mae': mae,
        'RMSE': rmse,
        'R2': r2,
        "run_id": run_id
    }