if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter
import pandas as pd
import boto3
import os
import time
import uuid
import numpy as np

def generate_uuid(n):
    ride_id = [str(uuid.uuid4()) for _ in range(n)]
    return ride_id

@data_exporter
def export_data(data, data_2, data_3, *args, **kwargs):
    """
    Exports data to an S3 bucket using the best-tuned model.

    Args:
        data: The original data frame and file source
        data_2: The output from the transform block (processed features and target)
        data_3: The output from the tuning block (best-tuned model and params)

    Output:
        Information about the exported file
    """
    # Extract the original filename from file_source
    df = data[0]
    file_source = data[1]
    original_filename = os.path.basename(file_source)
    original_filename_without_ext = os.path.splitext(original_filename)[0]

    # Configure S3 client
    s3 = boto3.client('s3',
                      endpoint_url='http://localstack:4566',
                      aws_access_key_id='test',
                      aws_secret_access_key='test',
                      region_name='us-east-1')

    # Extract necessary data
    best_tuned_model = data_3['best_model']
    best_params = data_3['best_params']
    X_train = data_2['X_train']
    X_test = data_2['X_test']

    # Concatenate train and test sets
    features_encoded = pd.concat([X_train, X_test])

    # Ensure indices align between features_encoded and original DataFrame
    features_encoded.reset_index(drop=True, inplace=True)
    df.reset_index(drop=True, inplace=True)

    # Generate predictions for the entire dataset using the best-tuned model
    y_pred_all = best_tuned_model.predict(features_encoded)

    # Ensure predictions and original data lengths match
    if len(y_pred_all) != len(df):
        # Filter df to match features_encoded
        df = df.iloc[:len(y_pred_all)].reset_index(drop=True)

    # Create a new dataframe with relevant columns and predictions from the original dataframe
    output_df = df[['Trip Miles', 'Trip Start Timestamp', 'Trip End Timestamp', 'Payment Type', 'Company', 'Duration']].copy()

    # Rename Duration column to Actual Duration
    output_df.rename(columns={'Duration': 'Actual Duration'}, inplace=True)

    # Add Predicted Duration column
    output_df['Predicted Duration'] = np.round(y_pred_all, 2)

    # Add Ride ID column
    output_df['Ride ID'] = generate_uuid(len(output_df))

    # Add Difference column (Actual Duration - Predicted Duration)
    output_df['Difference'] = round(output_df['Actual Duration'] - output_df['Predicted Duration'], 2)

    # Add Model Version column
    output_df['Model Version'] = data_3['run_id']

    # Reorder columns to make Ride ID the first column
    cols = ['Ride ID', 'Trip Miles', 'Trip Start Timestamp', 'Trip End Timestamp', 'Payment Type', 'Company', 'Actual Duration', 'Predicted Duration', 'Difference', 'Model Version']
    output_df = output_df[cols]

    # Create a dynamic filename with the original filename and timestamp
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_filename = f'{original_filename_without_ext}_{timestamp}.csv'

    # Save the DataFrame to a temporary CSV file
    temp_file_path = f'/tmp/{output_filename}'
    output_df.to_csv(temp_file_path, index=False)

    # Upload the file to S3
    bucket_name = 'mlflow-bucket'
    s3_key = f'output/{output_filename}'
    
    try:
        s3.upload_file(temp_file_path, bucket_name, s3_key)
        print(f"Output CSV file '{output_filename}' has been saved to the S3 bucket.")
    except Exception as e:
        print(f"Error uploading file to S3: {str(e)}")
    finally:
        # Clean up the temporary file
        os.remove(temp_file_path)

    return {
        'filename': output_filename,
        's3_path': f's3://{bucket_name}/{s3_key}',
        'num_rows': len(output_df),
        'best_model_name': data_3['best_model_name'],
        'best_params': best_params,
        'model_performance': {
            'MAE': data_3['mae'],
            'RMSE': data_3['RMSE'],
            'R2': data_3['R2']
        }
    }
