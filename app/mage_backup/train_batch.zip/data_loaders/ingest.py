if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import os
import pandas as pd
import boto3
from mlflow import set_tracking_uri
from io import StringIO
import random

# Choose a random month between 01 and 06
random_month = f'{random.randint(1, 6):02}'

# Dynamically set the file source with the random month
file_source = f's3://mlflow-bucket/dataset/Taxi_Trips_2024_{random_month}.csv'

@data_loader
def load_data(*args, **kwargs):
    """
    Load data from a CSV file stored in S3 using LocalStack.
    
    Returns:
        pandas.DataFrame: The loaded data as a DataFrame.
    """
    # Set environment variables for MLflow to use LocalStack S3
    os.environ['MLFLOW_S3_ENDPOINT_URL'] = 'http://localstack:4566'
    os.environ['AWS_ACCESS_KEY_ID'] = 'test'
    os.environ['AWS_SECRET_ACCESS_KEY'] = 'test'
    os.environ['MLFLOW_TRACKING_URI'] = 'http://mlflow:5000'

    set_tracking_uri('http://mlflow:5000')

    # Configure the S3 client to use LocalStack
    s3 = boto3.client('s3', 
                      endpoint_url='http://localstack:4566',
                      aws_access_key_id='test',
                      aws_secret_access_key='test',
                      region_name='us-east-1')

    # Parse the file source to extract the bucket name and file key
    bucket_name = file_source.split('/')[2]
    file_key = '/'.join(file_source.split('/')[3:])

    # Check if the bucket exists and create it if not
    try:
        s3.head_bucket(Bucket=bucket_name)
        print(f"Bucket '{bucket_name}' already exists.")
    except s3.exceptions.ClientError as e:
        if e.response['Error']['Code'] == '404':
            print(f"Bucket '{bucket_name}' not found. Creating bucket.")
            s3.create_bucket(Bucket=bucket_name)
        else:
            print(f"Error checking bucket: {e}")
            return None

    # Attempt to read the specified file
    try:
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        csv_content = response['Body'].read().decode('utf-8')
        df = pd.read_csv(StringIO(csv_content))
    except s3.exceptions.NoSuchKey:
        print(f"The specified key '{file_key}' does not exist.")
        return None
    except Exception as e:
        print(f"Error reading file from S3: {e}")
        return None

    return df, file_source