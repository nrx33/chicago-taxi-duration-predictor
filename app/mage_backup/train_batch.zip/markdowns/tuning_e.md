### Tunes the best model to improve the performance even further
### The tuned model gets registered on the mlflow registry